//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//	Copyright © 2025 Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com with 
//  acknowledgement & thanks to Melchor Varela © 2010, EA4FRB Madrid, Spain 
//	(melchor.varela@gmail.com) for the overall software and ideas.
//  
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	morse.h
// 	AUTHOR:		G1OJS - Alan Robinson
// 	DESCRIPTION	
// 	HISTORY
//	NAME   		DATE		REMARKS
//	AJR			Feb 2025	G1OJS  - creation
//*****************************************************************************/
//*****************************************************************************/
#ifndef __MORSE_H__
#define __MORSE_H__

#include <stdlib.h>
#include <m8c.h>

//-----------------------------------------------------------------------------
//  Prototypes
//-----------------------------------------------------------------------------
void Morse_U(void);
void Morse_K(void);
void Morse_Err(void);
void Morse_End(void);
void Morse_Dit(void);
void Morse_Dah(void);
void Tone(WORD wPitch_Hz, BYTE bLen_ms);

//-----------------------------------------------------------------------------
#endif
