//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//  Copyright © 2010 Melchor Varela - EA4FRB.  All rights reserved.
//  Melchor Varela, Madrid, Spain.
//  melchor.varela@gmail.com
//
//  Modifications Copyright © 2024,2025 Alan Robinson G1OJS 
//	Alan Robinson, Hampshire England G1OJS@yahoo.com 
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	GLB_DATA.C
// 	AUTHOR:		EA4FRB - Melchor Varela
//
// 	DESCRIPTION
//
//	Global constants and variables
//
// 	HISTORY
//
//	NAME   	DATE		REMARKS
//
//	MVM	   	DEC 2009	Creation
//
//  AJR			JAN 2025	Align data with refactoring and functional changes	
//
//*****************************************************************************
// 	IMAGECRAFT COMPILER TYPE DEFINITIONS
// 	From page 17 of the ImageCraft C Compiler Guide, Document # 001-44476 Rev *A
//
//	Type				Bytes		Range
//	[unsigned] char			1		0 .. 255
//      signed char			1		-128 .. 127
//
//	unsigned int			2		0 .. 65535
//	[signed] int			2		-32786 .. 32767
//
//	unsigned int|short		2		0 .. 65535
//	[signed] int|short		2		-32786 .. 32767
//
//	unsigned long			4		0 .. 4,294,967,295
//	[signed] long			4		-2,147,483,648 .. 2,147,483,647
//
//	float | double			4		1.175e-38 .. 3.40e+38
//
//	enum					1		if enum < 256
//							2		if enum >= 256
//
//	BOOL  = unsigned char   1		0 .. 255
//	BYTE  = unsigned char	1		0 .. 255
//	CHAR  = signed char		1		-128 .. 127
//	WORD  = unsigned int	2		0 .. 65535
//	INT   = signed int		2		-32786 .. 32767
//	DWORD = unsigned long	4		0 .. 4,294,967,295
//	LONG  = signed long		4		-2,147,483,648 .. 2,147,483,647
//
//*****************************************************************************
//
//
//
#include "glb_data.h"
#include "PSoCAPI.h"

//-----------------------------------------------------------------------------
//  Public data:
//-----------------------------------------------------------------------------

// counters decremented by sleep timer
volatile BYTE g_bIdleCounter = 0;
volatile BYTE g_bMeasureCounter = 0;
volatile BYTE g_bDebounceCounter = 0;
volatile BYTE g_bLongPressKeyCounter = 0;
volatile BYTE g_bSixtyFourthSecondCounter = 0;


BYTE g_bLongPress = 0;					// global flag for long key press
BYTE g_buffer16[16];					// global generic string buffer
BYTE g_bMode = MODE_IMP;				// current measurement mode

// constants for true calibration data
const WORD g_wBridgeRatiosTrueArr[CAL_LOAD_NUM][2] = {
//{100, 818},									//  5  Ohms
{200, 667},									// 10  Ohms
//{500, 333},									// 25 Ohms
{1000, MINMODGAMMATRUE},						// 50  Ohms	
//{3000,500},									// 150 Ohms
{4400,630},									// 220 Ohms
//{9400,808},									// 470 Ohms
//{11200,836}									// 560 Ohms
};

// storage for measured calibration data	
signed char g_scCalTable[CAL_FREQS_NUM][CAL_LOAD_NUM][2] = {0}; 
// calibration state
BYTE g_bIsCalibrated=FALSE;				// TRUE if calibrated
BYTE g_bDDS_GainStep=8;					// Default DDS gain step

// Current results of impedance measurements
WORD g_wBridgeRatios[2];				// Measured bridge ratios			
WORD g_wSwr100;							// SWR x 100
WORD g_wZ10;							// |Z|_ohms x 10 
WORD g_wX10;							// X_ohms x 10
WORD g_wR10;							// R_ohms x 10
WORD g_wL10;							// L_uH x 10
WORD g_wC10;							// C_pF x 10
BYTE g_bSgnX = '?';						// sign of reactance

// Storage, choices and defaults for user preferences
CONFIG_DATA g_xConf;										// Storage structure
const BYTE g_bUserIdle[USER_IDLE_NUM]	= {0,30,60,90};		
const BYTE g_bCWPitches[CWPitch_NUM]	= {6,10,12,20,24};  
const BYTE g_bVF[VF_NUM] 				= {99,81,66};		
const BYTE g_bFltWd100kHz[FLT_WT_NUM] 	= {0,2,10,40};		

// frequency and band settings
BYTE g_bBandIndex;
DWORD g_dwCurrHz;
const WORD g_wBandBoundaries[BAND_NUM+1]= {9,20,40,60,80, 110,130,170,190,230,260,280,310,400,490,550,650};
const WORD g_wBandInitialFreq[BAND_NUM] = {18,37,53,71,101,120,141,181,211,249,270,282,355,445,503,570};

// Keyboard flags for modes entered 'live' on display
BYTE g_bUP_DOWN_SelectsIncDigit 	= FALSE;			// select the frequency digit to use with UP/DOWN
BYTE g_bUP_DOWN_SelectsVFOPower		= FALSE;			// select VFO output power with UP/DOWN

// Frequency setting by UP/DOWN keys: cursor column to inrement in Hz
BYTE g_bIncDigit=5;
const INCREMENT_CONTROL g_xIncCtrl[NUM_INCREMENT] =
{
	{15, 1},
	{14, 10},
	{13, 100},		// skip decimal point 
	{11, 1000},
	{10, 10000},
	{9,  100000},
	{8,  1000000},
	{7,  10000000}
};

// PGA DDS gain settings table
const GAIN_DDS g_xGainDds[GAIN_SETTINGS_NUM] =
{
   {PGA_DDS_1_G0_68,PGA_DDS_2_G0_68},  // 0.68x0.68=0.46 Iset = 0.015 amplified Vout = 0.190pp = -10.5 dBm
   {PGA_DDS_1_G1_46,PGA_DDS_2_G0_31},  // 1.46x0.31=0.45 Iset = 0.021 amplified Vout = 0.273pp = -7.3 dBm
   {PGA_DDS_1_G1_46,PGA_DDS_2_G0_31},  // 1.46x0.31=0.45 Iset = 0.021 amplified Vout = 0.273pp = -7.3 dBm
   {PGA_DDS_1_G1_78,PGA_DDS_2_G0_25},  // 1.78x0.25=0.45 Iset = 0.026 amplified Vout = 0.338pp = -5.4 dBm
   {PGA_DDS_1_G0_43,PGA_DDS_2_G1_00},  // 0.43x1.00=0.43 Iset = 0.036 amplified Vout = 0.466pp = -2.7 dBm
   {PGA_DDS_1_G0_56,PGA_DDS_2_G0_75},  // 0.56x0.75=0.42 Iset = 0.043 amplified Vout = 0.551pp = -1.2 dBm
   {PGA_DDS_1_G0_50,PGA_DDS_2_G0_81},  // 0.50x0.81=0.41 Iset = 0.053 amplified Vout = 0.679pp = 0.6 dBm
   {PGA_DDS_1_G1_06,PGA_DDS_2_G0_37},  // 1.06x0.37=0.39 Iset = 0.062 amplified Vout = 0.789pp = 1.9 dBm
   {PGA_DDS_1_G1_00,PGA_DDS_2_G0_37},  // 1.00x0.37=0.37 Iset = 0.076 amplified Vout = 0.978pp = 3.8 dBm
   {PGA_DDS_1_G0_56,PGA_DDS_2_G0_62},  // 0.56x0.62=0.35 Iset = 0.092 amplified Vout = 1.173pp = 5.4 dBm
   {PGA_DDS_1_G1_78,PGA_DDS_2_G0_18},  // 1.78x0.18=0.32 Iset = 0.109 amplified Vout = 1.401pp = 6.9 dBm
   {PGA_DDS_1_G1_60,PGA_DDS_2_G0_18},  // 1.60x0.18=0.29 Iset = 0.131 amplified Vout = 1.678pp = 8.5 dBm
   {PGA_DDS_1_G0_50,PGA_DDS_2_G0_50},  // 0.50x0.50=0.25 Iset = 0.156 amplified Vout = 2.002pp = 10.0 dBm
   {PGA_DDS_1_G0_81,PGA_DDS_2_G0_25},  // 0.81x0.25=0.20 Iset = 0.188 amplified Vout = 2.407pp = 11.6 dBm
   {PGA_DDS_1_G1_23,PGA_DDS_2_G0_12},  // 1.23x0.12=0.15 Iset = 0.225 amplified Vout = 2.876pp = 13.2 dBm
   {PGA_DDS_1_G1_33,PGA_DDS_2_G0_06},  // 1.33x0.06=0.08 Iset = 0.270 amplified Vout = 3.454pp = 14.7 dBm
   {PGA_DDS_1_G0_43,PGA_DDS_2_G0_06}   // 0.43x0.06=0.03 Iset = 0.306 amplified Vout = 3.915pp = 15.8 dBm
};
