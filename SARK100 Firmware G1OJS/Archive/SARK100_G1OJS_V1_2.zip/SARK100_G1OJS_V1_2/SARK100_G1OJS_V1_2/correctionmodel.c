//*****************************************************************************/
//  This file is a part of the "SARK100 SWR Analyzer firmware"
//
//	Copyright © 2025 Alan Robinson G1OJS Hampshire England G1OJS@yahoo.com with 
//  acknowledgement & thanks to Melchor Varela © 2010, EA4FRB Madrid, Spain 
//	(melchor.varela@gmail.com) for the overall software and ideas.
//
//  "SARK100 SWR Analyzer firmware" is free software: you can redistribute it
//  and/or modify it under the terms of the GNU General Public License as
//  published by the Free Software Foundation, either version 3 of the License,
//  or (at your option) any later version.
//
//  "SARK100 SWR Analyzer firmware" is distributed in the hope that it will be
//  useful,  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with "SARK100 SWR Analyzer firmware".  If not,
//  see <http://www.gnu.org/licenses/>.
//*****************************************************************************/
//*****************************************************************************/
//
//	PROJECT:	SARK100 SWR Analyzer
// 	FILE NAME: 	correctionmodel.c
// 	AUTHOR:		Alan Robinson
//
// 	DESCRIPTION: Characterises the bridge by recording the measured bridge ratios
//				 across frequency for a set of known loads. Encodes the characterisation
//				 data using a Moebius Transform for compact storage. Decodes the 
//				 characterisation data and corrects measurements.
//
// 	HISTORY
//	NAME   	DATE		REMARKS
//	AJR		JAN 2025	Creation
//*****************************************************************************/
#include "correctionmodel.h"

#include "control.h"
#include "storage.h"
#include "glb_data.h"
#include "keypad.h"
#include "msg_generic.h"
#include "morse.h"
#include "screens.h"
#include "bridge.h"
#include "derive.h"
#include "timers.h"
#include "UART.h"
#include "pclink_cmds.h"


typedef enum {STORE, RETRIEVE} ENCODE_DIRECTION;

//-----------------------------------------------------------------------------
//  Prototypes
//-----------------------------------------------------------------------------
WORD CalRatio(BYTE gbLoad, RATIO_TYPE rRatio);
static WORD wXPrime(DWORD dwX, DWORD dwX1, DWORD dwX2, DWORD dwXPrime1, DWORD dwXprime2);
static INT iRatioFromCalibration(ENCODE_DIRECTION xDir, RATIO_TYPE xType, INT iRatio_true, INT iRatio);
BYTE getUserConfirmation(void);
//-----------------------------------------------------------------------------
//  Defines
//-----------------------------------------------------------------------------
// Full scale value with a little headroom for upward fluctuations with frequency
#define VF_REFERENCE_LEVEL	3900 
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	MeasureUncorrectedRatios()
//  DESCRIPTION:	Calibration routine
//  ARGUMENTS: 		none.
//  RETURNS:		none.
//-----------------------------------------------------------------------------
void MeasureUncorrectedRatios (void)
{
	WORD wCalFreqIndex;
	BYTE bCalFreqIndex;
	BYTE bFirst;
	RATIO_TYPE rRatio;
	BYTE bLoad;
	M8C_EnableGInt ;
	
	//#define debug TRUE

	#ifdef debug
		UART_CmdReset(); 					// Initialize receiver/cmd buffer
		UART_IntCntl(UART_ENABLE_RX_INT); 	// Enable RX interrupts
		UART_Start(UART_PARITY_NONE); 		// Enable UART
	#endif
	
	do
	{
		Screen_Clear();
		Screen_HideCursor();
	
		// Find DDS Gain step needed for reasonable Vf 
		// This is also an opportunity to abort the calibration without changing anything:
		Screen_Clear(); Screen_CStrAtRowCol(0,0, gDisconnectLoadStr);
		if(!getUserConfirmation()) break;
  		Screen_CStrAtRowCol(1, 0, gSettingGainStr);
		g_dwCurrHz=FREQ_MIN_Hz;
		Screen_Frequency(Display_Hz);
		for (g_bDDS_GainStep=0;g_bDDS_GainStep<GAIN_SETTINGS_NUM;g_bDDS_GainStep++)
		{
			PGA_DDS_1_SetGain(g_xGainDds[g_bDDS_GainStep].bGain1);
			PGA_DDS_2_SetGain(g_xGainDds[g_bDDS_GainStep].bGain2);
			if ( (wRead_ADC_DDSON(VfPort) >= VF_REFERENCE_LEVEL) || (g_bDDS_GainStep==(GAIN_SETTINGS_NUM-1) ) ) break;
		}
	
		// now measure and store the uncalibrated ratios Vz/Va and Vr/Vf at each cal frequency and load			
		for (bLoad=0; bLoad < CAL_LOAD_NUM; bLoad++)
		{
			Morse_Dah();
			Screen_Clear(); Screen_CStrAtRowCol(0,0, gCalLoadStr[bLoad]);
			if(!getUserConfirmation()) break;
			Screen_Clear(); Screen_CStrAtRowCol(1, 0, gCalibratingStr);
			for (wCalFreqIndex=0; wCalFreqIndex<CAL_FREQS_NUM;wCalFreqIndex++)
			{
				g_dwCurrHz=CAL_START_kHz*1000 + (DWORD)wCalFreqIndex * CAL_FREQ_STEP_kHz*1000 ;
				Screen_Frequency(Display_Hz);
				MeasureBridgeRatios();
				for (rRatio=MODZ; rRatio <= MODGAMMA; rRatio++) {
					g_scCalTable[wCalFreqIndex][bLoad][rRatio] = (BYTE)iRatioFromCalibration(STORE, rRatio, g_wBridgeRatiosTrueArr[bLoad][rRatio], g_wBridgeRatios[rRatio]);
				}
			}
		}

		// Store cal factors in EEPROM
		g_bIsCalibrated=TRUE; // this needs to be set to True here, and only here
		STR_SaveCalibration();
	
		// Finish, alert user
		Screen_Clear();
		Screen_CStrAtRowCol(0,0, gConfigDoCalStr);
		Screen_CStrAtRowCol(1,0, gDoneRestartingStr);
		Morse_End();
		Delay_64ths(TIME_FLASH_MSG);
		M8C_DisableGInt;
		asm ("ljmp 0x0000"); // Perform Software Reset
	
	} while (FALSE);

}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	iRatioFromCalibration
//
//  DESCRIPTION:	Encodes or decodes a ratio measured during calibration 
//					so that the encoded result can be stored in the
//					BYTE arrays [bCalFreqIndex][gbLoad] 
//					The measured ratio is first scaled to the true ratio, and then
//					log-like encoding is used to allow (measured/true) to range from
//						1/2 to 2 for (Vr/Vf measured) / (Vr/Vf true) -> -127 to 127 
//						1/5 to 5 for (Vz/Va measured) / (Vz/Va true) -> -127 to 127
//					hence the result can be encoded in an array of signed char.
//					Using signed innteger for the output and inputs means that the
//					single function can be used in each direction (encode & decode)
//
//  ARGUMENTS:		xDir		= STORE | RETRIEVE
//					xType	 	= MODZ | MODGAMMA
//					iRatio_true	= true ratio for the cal point scaled by wUNITY
//					iRatio		= ratio scaled by wUNITY, or encoded value, to convert 
//
//  RETURNS: 		signed int	= encoded value (range -127 to 127) when encoding
//					signed int	= Measured ratio (range 0 to 32767 scaled by wUNITY) when decoding
//
//	NOTES:			Whilst |Z|/50 can range to 65537/wUNITY, 32767 is enough for
//					the largest calibration load (560 ohms, true ratio 11200/wUNITY)
//					|Gamma| ranges 0 to 1000/wUNITY or slightly over with measurement error
//					The encoded output has zero indicating measured ratio = true ratio, so
//					the calibration table is initialised to zero by default
//-----------------------------------------------------------------------------

static INT iRatioFromCalibration(ENCODE_DIRECTION xDir, RATIO_TYPE xType, INT iRatio_true, INT iRatio) {
	long lNum;
	long lDenom;
	INT iScale;
	BYTE bDyRNG = (xType==MODGAMMA)? 3:6; 	// dynamic range 1/n to n
	
	#define ENC_MAX 127						// encoded range -127 to +127
	
	iScale = (ENC_MAX*(int)(bDyRNG+1)) /(int)(bDyRNG-1);

	if(xDir==STORE) {
    	lNum = iScale*(long)iRatio - (long)iScale*(long)iRatio_true;
    	lDenom = (long)iRatio + (long)iRatio_true;
		if (lDenom==0) {return 0;} else {				// lim x,y->0 of (x-y)/(x+y) is 0
			lNum /=lDenom;								// re-using the numerator var for the result
			lNum = (lNum>ENC_MAX)? ENC_MAX:lNum;		// clamp at +/- ENC_MAX; better than wrapped if stored in 8 bits
			lNum = (lNum<-ENC_MAX)? -ENC_MAX:lNum;		
    		return lNum; 
		}
	} else {
	    lNum = (long)iRatio_true*(long)iScale+(long)iRatio_true*(long)iRatio;
    	lDenom = (long)iScale - (long)iRatio;
    	return lNum / lDenom;  
	}
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	CorrectBridgeRatios()
//  DESCRIPTION:	Use a mapping function to map the current measured ratios
//					to the true values that they should represent.
//  ARGUMENTS:		none
//  RETURNS: 		nothing
//-----------------------------------------------------------------------------
void CorrectBridgeRatios (void)
{
	BYTE bLowerLoad;
	signed char scSignMG;
	WORD wMG_CorrFact1[2];
	WORD wMG_CorrFact2[2];

	// find cal loads such that one load has |Z|<|ZL| and the other has |Z|>|ZL|
	bLowerLoad=0;
	do { 
		if ( CalRatio(bLowerLoad+1,MODZ) >= g_wBridgeRatios[MODZ]) break;
	} while (bLowerLoad++ < CAL_LOAD_NUM-3);  // this looks strange but is needed so that bLowerLoad ranges [0 .. nLoads-2] (Upper load= [1 .. nLoads-1])	
 	// map ZL from (cal measure load1 .... cal measure load2) to (cal load1 true ... cal load 2 true)
 	g_wBridgeRatios[MODZ] = wXPrime(g_wBridgeRatios[MODZ], CalRatio(bLowerLoad,MODZ), CalRatio(bLowerLoad+1,MODZ),
									g_wBridgeRatiosTrueArr[bLowerLoad][MODZ],  g_wBridgeRatiosTrueArr[bLowerLoad+1][MODZ]);									

	// find cal loads with |Z|<50 such that one load has |gamma|>|gamma|L and the other has |gamma|<|gamma|L
	bLowerLoad=0;
	do { 
		if ( (signed int)-1*CalRatio(bLowerLoad+1,MODGAMMA) >= (signed int)-1*g_wBridgeRatios[MODGAMMA]) break;
		bLowerLoad++;
	} while (g_wBridgeRatiosTrueArr[bLowerLoad+1][MODGAMMA] !=MINMODGAMMATRUE); 									
	// calculate correction factor from |gamma| measured to |gamma| true where |Z|<50
	// and record the impedance associated with this reflection coefficient
	wMG_CorrFact1[0]=wDivide(wXPrime(g_wBridgeRatios[MODGAMMA], CalRatio(bLowerLoad,MODGAMMA), CalRatio(bLowerLoad+1,MODGAMMA),
									g_wBridgeRatiosTrueArr[bLowerLoad][MODGAMMA],  g_wBridgeRatiosTrueArr[bLowerLoad+1][MODGAMMA]),g_wBridgeRatios[MODGAMMA]);
	wMG_CorrFact1[1]=wXPrime(g_wBridgeRatios[MODGAMMA],g_wBridgeRatiosTrueArr[bLowerLoad][MODGAMMA],  g_wBridgeRatiosTrueArr[bLowerLoad+1][MODGAMMA],
									g_wBridgeRatiosTrueArr[bLowerLoad][MODZ],  g_wBridgeRatiosTrueArr[bLowerLoad+1][MODZ]);
	// now carry on in the load table to do the same again but now |Z|>50
	do { 
		if ( CalRatio(bLowerLoad+1,MODGAMMA) >= g_wBridgeRatios[MODGAMMA]) break;
	} while ((bLowerLoad++ < CAL_LOAD_NUM-3)); 
	// calculate correction factor from |gamma| measured to |gamma| true where |Z|>50		
	// and record the impedance associated with this reflection coefficient
	wMG_CorrFact2[0]=wDivide(wXPrime(g_wBridgeRatios[MODGAMMA], CalRatio(bLowerLoad,MODGAMMA), CalRatio(bLowerLoad+1,MODGAMMA),
									g_wBridgeRatiosTrueArr[bLowerLoad][MODGAMMA],  g_wBridgeRatiosTrueArr[bLowerLoad+1][MODGAMMA]),g_wBridgeRatios[MODGAMMA]);
	wMG_CorrFact2[1]=wXPrime(g_wBridgeRatios[MODGAMMA],g_wBridgeRatiosTrueArr[bLowerLoad][MODGAMMA],  g_wBridgeRatiosTrueArr[bLowerLoad+1][MODGAMMA],
									g_wBridgeRatiosTrueArr[bLowerLoad][MODZ],  g_wBridgeRatiosTrueArr[bLowerLoad+1][MODZ]);

	// reuse the wMG_CorrFact1[0] variable to hold the weighted average of wMG_CorrFact1[0],wMG_CorrFact2[0],
	// weighted according to the measured MODZ relative to the MODZs at the two correction factor points
	// but don't extrapolate (as measured values can be extreme)
	#define minmax(x,a,b) (x<a)? a:((x>b)? b:x)
	wMG_CorrFact1[0] = wXPrime(minmax(g_wBridgeRatios[MODZ], wMG_CorrFact1[1], wMG_CorrFact2[1]),
								wMG_CorrFact1[1],wMG_CorrFact2[1],
								wMG_CorrFact1[0],wMG_CorrFact2[0]);
								
	// apply the correction factor for |gamma|
	g_wBridgeRatios[MODGAMMA] = ((DWORD)g_wBridgeRatios[MODGAMMA]*(DWORD)wMG_CorrFact1[0]) / wUNITY;
		
	// Vr>Vf represents a failure in the assumptions in the calibration model and is better corrected by a simple cap
	// Also calculating SWRx100 in WORD from wUNITYxVr/Vf needs wUNITYxVr/Vf slightly less than wUNITY, so cap at that value rather than wUNITY  
	if(g_wBridgeRatios[MODGAMMA] > VR_OVER_VF_NUM) g_wBridgeRatios[MODGAMMA] = VR_OVER_VF_NUM;
}

//-----------------------------------------------------------------------------
//  FUNCTION NAME:	CalRatio(BYTE bLoad, RATIO_TYPE rRatio)
//  DESCRIPTION:	Retrieves the ratio measured during calibration
//					interpolated to the current frequency g_dwCurrHz
//  ARGUMENTS:		bLoad - the load index
//					rRatio - MODZ | MODGAMMA
//  RETURNS:		(rRatio = MODGAMMA): Vr/Vf; (grRatio=MODZ): Va/Vz
//-----------------------------------------------------------------------------
WORD CalRatio(BYTE bLoad, RATIO_TYPE rRatio) 
{
	BYTE bCalFreqIndex = (g_dwCurrHz/1000-CAL_START_kHz) / (CAL_FREQ_STEP_kHz);
	return wXPrime(g_dwCurrHz/1000-CAL_START_kHz, (DWORD)bCalFreqIndex * CAL_FREQ_STEP_kHz, (DWORD)(1+bCalFreqIndex) * CAL_FREQ_STEP_kHz,
		iRatioFromCalibration(RETRIEVE, rRatio, g_wBridgeRatiosTrueArr[bLoad][rRatio], g_scCalTable[bCalFreqIndex][bLoad][rRatio]), 
		iRatioFromCalibration(RETRIEVE, rRatio, g_wBridgeRatiosTrueArr[bLoad][rRatio], g_scCalTable[bCalFreqIndex+1][bLoad][rRatio]) );		
}
//-----------------------------------------------------------------------------
//  FUNCTION NAME:	wXPrime(DWORD dwX, DWORD dwX1, DWORD dwX2, DWORD dwXPrime1, DWORD dwXPrime2)
//  DESCRIPTION:	Maps the range dwX1 .. dwX2 onto dwX1' .. dwX2'
//  				The function works to the precision set by the wUNITY #def
//  ARGUMENTS:
//		dwX - the value to map
//		dwX1, dwX2, dwX1', dwX2' end points of the mapping ranges
//  RETURNS:
//     	wX' - the input value mapped into the range dwX1' .. dwX2'
//-----------------------------------------------------------------------------
static WORD wXPrime(DWORD dwX, DWORD dwX1, DWORD dwX2, DWORD dwXPrime1, DWORD dwXPrime2)
{
	// inputs are DWORD because of need to scale numerator again by wUNITY
	// use signed below because (wUNITY - lAlpha) can be negative
	long lAlpha = (long)(wUNITY*(long)(dwX - dwX1)) / (long)(dwX2 - dwX1);
	long tmp = (long)(lAlpha * (long)dwXPrime2)/(long)wUNITY;
	tmp += (long)dwXPrime1*((long)wUNITY - lAlpha)/(long)wUNITY;
	if(tmp < 0) tmp=0;
	if(tmp > WORD_MAX) tmp=WORD_MAX;
	return (WORD)tmp;
}



