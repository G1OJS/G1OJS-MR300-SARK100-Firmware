
import subprocess
import os
import pandas as pd
from PyLTSpice import SimCommander
from helpers import log

def run_bridge_sweep(
    asc_file,
    ltspice_exe,
    load_values=[5, 50, 500],
    source_voltages=[0.1, 0.5, 1.0],
    frequencies=(1e6, 50e6, 100),
    work_dir="./ltspice_runs",
    save_csv=True
):
    """Run LTSpice bridge voltage sweep over load, frequency, and source voltage."""

    os.makedirs(work_dir, exist_ok=True)
    results = []

    for load in load_values:
        for Vsrc in source_voltages:

            raw_file = os.path.join(work_dir, f"Bridge_{load}R_{Vsrc}V.raw")

            # Run LTSpice
            log(f"Running LTSpice: Rload={load} Ω, Vsrc={Vsrc} V")
            cmd = [
                ltspice_exe, "-b", asc_file,
                "-ar", f"Rload={load}",
                "-ar", f"Vsrc={Vsrc}",
                "-r", raw_file
            ]
            log(" ".join(cmd))
            subprocess.run(cmd, check=True)

            # Extract .raw output
            log(f"Reading simulation result: {raw_file}")
            sim = SimCommander(raw_file)
            sim.wait_completion()
            data = sim.get_waveforms()

            freqs = data.get_frequency()
            Va = data.get_waveform('Va')
            Vr = data.get_waveform('Vr')
            Vz = data.get_waveform('Vz')
            Vf = data.get_waveform('Vf')

            for fval, va, vr, vz, vf in zip(freqs, Va.real, Vr.real, Vz.real, Vf.real):
                results.append({
                    "Load_Ohm": load,
                    "Vsrc_V": Vsrc,
                    "Frequency_Hz": fval,
                    "Va": va,
                    "Vr": vr,
                    "Vz": vz,
                    "Vf": vf
                })

    # Save CSV
    df = pd.DataFrame(results)
    if save_csv:
        output_file = os.path.join(work_dir, "bridge_voltage_sweep.csv")
        df.to_csv(output_file, index=False)
        log(f"Results saved to {output_file}")

    return df
