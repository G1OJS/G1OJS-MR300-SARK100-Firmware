
import pandas as pd
import os
import csv

def convert_sim_csv_to_voltagefile(sim_csv_path, output_path):
    """Convert LTSpice simulation CSV to structured voltage file format."""
    df = pd.read_csv(sim_csv_path)

    # Group by load and source voltage to create series
    grouped = df.groupby(['Load_Ohm', 'Vsrc_V'])

    with open(output_path, 'w', newline='') as f:
        writer = csv.writer(f)
        for (load, vsrc), group in grouped:
            series_id = f"Sim_R_{int(load)}_Vsrc_{vsrc:.1f}"
            writer.writerow([series_id, f"Simulated {load}Ω {vsrc}V", "None", "None", "None", "Sim", "None"])
            for _, row in group.iterrows():
                MHz = row['Frequency_Hz'] / 1e6
                writer.writerow([
                    f"{MHz:.6f}",
                    f"{row['Vf']:.8e}",
                    f"{row['Vr']:.8e}",
                    f"{row['Vz']:.8e}",
                    f"{row['Va']:.8e}"
                ])

    print(f"Converted simulation CSV to voltage file format: {output_path}")
